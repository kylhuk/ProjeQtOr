<?php

namespace Ticketpark\HtmlPhpExcel\Exception;

/**
 * Base exception class
 *
 * @author Manuel Reinhard <manu@sprain.ch>
 */
class HtmlPhpExcelException extends \Exception
{
}
