<?php

namespace Ticketpark\HtmlPhpExcel\Elements;

interface Element {};