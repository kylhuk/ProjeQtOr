-- ///////////////////////////////////////////////////////////
-- // PROJECTOR                                             //
-- //-------------------------------------------------------//
-- // Version : V2.1.1                                      //
-- // Date : 2012-04-05                                     //
-- ///////////////////////////////////////////////////////////
--
-- PURGE OF ALL TABLES EXCEPT PARAMETERS

TRUNCATE TABLE `${prefix}action`;
TRUNCATE TABLE `${prefix}activity`;
TRUNCATE TABLE `${prefix}activityprice`;
TRUNCATE TABLE `${prefix}assignment`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
TRUNCATE TABLE `${prefix}`;
