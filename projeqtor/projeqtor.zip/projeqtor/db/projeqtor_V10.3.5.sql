-- ///////////////////////////////////////////////////////////
-- // PROJECTOR                                             //
-- //-------------------------------------------------------//
-- // Version : 10.3.5                                      //
-- // Date : 2023-05-17                                     //
-- ///////////////////////////////////////////////////////////
-- Patch on V10.3

INSERT INTO `${prefix}reportparameter` (`idReport`, `name`, `paramType`, `sortOrder`, `idle`, `defaultValue`) VALUES
(110,'showClosedItems','boolean',12,0,null);
