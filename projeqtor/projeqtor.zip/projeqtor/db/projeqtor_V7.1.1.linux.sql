-- ///////////////////////////////////////////////////////////
-- // PROJECTOR                                             //
-- //-------------------------------------------------------//
-- // Version : 7.1.1                                       //
-- // Date : 2018-06-04                                     //
-- // Note : specific for linux envs                        //
-- //        (where table name is case sensitive)           //
-- ///////////////////////////////////////////////////////////
--
--

RENAME TABLE `${prefix}resourceTeamAffectation` TO `${prefix}resourceteamaffectation`;